export class Course{
    constructor(public title: string, public summary: string)
    {
        
    }
}